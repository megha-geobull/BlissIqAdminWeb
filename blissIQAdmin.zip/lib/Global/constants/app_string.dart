// App Strings
class AppString {
  /// regular app strings
  static const String appName = "BlissIQ";
  static const String serverError = "Server Error";

  static const String rupeeSign = "₹";

  static const String delete = "delete";


}