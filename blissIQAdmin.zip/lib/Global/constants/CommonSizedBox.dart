 import 'package:flutter/material.dart';

SizedBox boxH02() => const SizedBox(height: 02);
SizedBox boxH05() => const SizedBox(height: 05);
SizedBox boxH08() => const SizedBox(height: 08);
SizedBox boxH10() => const SizedBox(height: 10);
SizedBox boxH15() => const SizedBox(height: 15);
SizedBox boxH20() => const SizedBox(height: 20);
SizedBox boxH25() => const SizedBox(height: 25);
SizedBox boxH30() => const SizedBox(height: 30);
SizedBox boxH50() => const SizedBox(height: 50);

SizedBox boxW02() => const SizedBox(width: 02);
SizedBox boxW05() => const SizedBox(width: 05);
SizedBox boxW08() => const SizedBox(width: 08);
SizedBox boxW10() => const SizedBox(width: 10);
SizedBox boxW15() => const SizedBox(width: 15);
SizedBox boxW20() => const SizedBox(width: 20);
SizedBox boxW25() => const SizedBox(width: 25);
SizedBox boxW30() => const SizedBox(width: 30);
SizedBox boxW50() => const SizedBox(width: 50);
