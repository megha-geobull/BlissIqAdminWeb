import 'package:flutter/material.dart';

class ConversationalScreen extends StatefulWidget {
  const ConversationalScreen({super.key});

  @override
  State<ConversationalScreen> createState() => _ConversationalScreenState();
}

class _ConversationalScreenState extends State<ConversationalScreen> {
  @override
  Widget build(BuildContext context) {
    return Column(

    );
  }
}
